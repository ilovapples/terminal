# Terminal
Terminal allows you to log into seperate accounts and access seperate files and use around seven different console commands.

## Update (March 10th, 2023):
At this point in time, the `terminal.py` script has been set to automatically run the scripts to get the directory, so unless you want to, all of the below information is technically useless. Just thought I'd tell you before you wasted time reading it, like I wasted time writing it. (Update, again: 3/29/23 8:30 PM, the rest of the README is gone, because I didn't feel like updating it when I migrated it to a seperate repo)
